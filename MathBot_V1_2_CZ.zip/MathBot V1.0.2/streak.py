import json
import sys
from pathlib import Path
from datetime import date, timedelta


def aktualizuj_streak():
    if getattr(sys, "frozen", False):
        slozka = Path(sys.executable).resolve().parent
    else:
        slozka = Path(__file__).resolve().parent

    soubor = slozka / "statistics.json"

    with open(soubor, "r", encoding="utf-8") as f:
        data = json.load(f)

    dnes = date.today()
    dnes_text = dnes.isoformat()

    posledni_den = data.get("last_practice_date")
    streak = int(data.get("streak", 0))

    if posledni_den == dnes_text:
        return streak

    vcera_text = (dnes - timedelta(days=1)).isoformat()

    if posledni_den == vcera_text:
        streak += 1
    else:
        streak = 1

    data["streak"] = streak
    data["last_practice_date"] = dnes_text

    with open(soubor, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

    return streak