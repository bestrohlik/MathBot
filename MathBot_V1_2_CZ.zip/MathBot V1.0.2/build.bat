@echo off
python -m PyInstaller --noconfirm --clean --onedir --console --noupx --name MathBot --icon=ikona.ico MathBot.py
xcopy /E /I /Y DLC dist\MathBot\DLC
copy /Y statistics.json dist\MathBot\statistics.json
pause