import os
import sys
import zipfile
import tempfile
import importlib.util
from pathlib import Path


def nacti_mathbot_dlc(cesta):
    """
    Načte DLC MathBotu a spustí jeho funkci MathBotHry().

    Podporuje:
    - složky s main.py
    - ZIP archivy s příponami .mathbot a .dlc
    - vnořené složky .mathbot a .dlc
    """

    cesta = Path(cesta).resolve()

    if not cesta.exists():
        print(f"DLC neexistuje: {cesta}")
        return False

    docasna_slozka = None

    try:
        # ==========================================
        # ROZBALENÍ DLC ARCHIVU
        # ==========================================

        if cesta.is_file():
            if not zipfile.is_zipfile(cesta):
                print("DLC není platný ZIP archiv!")
                return False

            docasna_slozka = tempfile.TemporaryDirectory(
                prefix="MathBotDLC_"
            )

            with zipfile.ZipFile(cesta, "r") as archiv:

                # Ochrana před zápisem mimo cílovou složku.
                cil = Path(docasna_slozka.name).resolve()

                for polozka in archiv.infolist():
                    cilova_cesta = (
                        cil / polozka.filename
                    ).resolve()

                    if not cilova_cesta.is_relative_to(cil):
                        raise ValueError(
                            "DLC obsahuje nebezpečnou cestu!"
                        )

                archiv.extractall(cil)

            koren = Path(docasna_slozka.name)

        else:
            koren = cesta

        # ==========================================
        # HLEDÁNÍ main.py
        # ==========================================

        kandidati = [
            koren / "main.py",
            koren / ".mathbot" / "main.py",
            koren / ".dlc" / "main.py",
            koren / "MathBotHry" / "main.py",
            koren / "MathBotHry" / ".mathbot" / "main.py",
            koren / "MathBotHry" / ".dlc" / "main.py",
        ]

        main_soubor = next(
            (
                soubor
                for soubor in kandidati
                if soubor.is_file()
            ),
            None
        )

        # Pokud je DLC zabaleno v další složce,
        # prohledáme také její podadresáře.
        if main_soubor is None:
            nalezene = sorted(
                soubor
                for soubor in koren.rglob("main.py")
                if ".mathbot" in soubor.parts
                or ".dlc" in soubor.parts
            )

            if nalezene:
                main_soubor = nalezene[0]

        if main_soubor is None:
            print("DLC neobsahuje podporovaný main.py!")
            return False

        # ==========================================
        # NAČTENÍ MODULU
        # ==========================================

        modul_nazev = "mathbot_dlc_" + str(
            abs(hash(str(main_soubor)))
        )

        specifikace = importlib.util.spec_from_file_location(
            modul_nazev,
            main_soubor
        )

        if specifikace is None or specifikace.loader is None:
            print("Nepodařilo se připravit DLC!")
            return False

        modul = importlib.util.module_from_spec(specifikace)

        sys.modules[modul_nazev] = modul

        # Umožní importy z adresáře DLC.
        sys.path.insert(0, str(main_soubor.parent))

        try:
            specifikace.loader.exec_module(modul)
        finally:
            if str(main_soubor.parent) in sys.path:
                sys.path.remove(str(main_soubor.parent))

        # ==========================================
        # SPUŠTĚNÍ HRY
        # ==========================================

        hra = getattr(modul, "MathBotHry", None)

        if not callable(hra):
            print(
                "V main.py chybí funkce MathBotHry()!"
            )
            return False

        print("MathBot DLC načteno!")
        print(f"Soubor: {main_soubor}")
        print("Spouštím MathBotHry()...")

        hra()

        return True

    except Exception as chyba:
        print(f"Chyba při načítání DLC: {chyba}")
        return False

    finally:
        if docasna_slozka is not None:
            docasna_slozka.cleanup()