import importlib.util
import json
import os
import random
import sys
from fractions import Fraction

# ==========================================
# SLOŽKA APLIKACE (vedle .exe nebo vedle .py)
# ==========================================

if getattr(sys, "frozen", False):
    slozka = os.path.dirname(sys.executable)
else:
    slozka = os.path.dirname(os.path.abspath(__file__))

if slozka not in sys.path:
    sys.path.insert(0, slozka)

# Pokud chybí statistics.json, vytvoří se nový (aby hra nespadla)
STAT_SOUBOR = os.path.join(slozka, "statistics.json")

if not os.path.exists(STAT_SOUBOR):
    with open(STAT_SOUBOR, "w", encoding="utf-8") as f:
        json.dump(
            {"xp": 0, "streak": 0, "last_practice_date": ""},
            f,
            indent=4,
            ensure_ascii=False,
        )

from XPGiver import pridej_xp
from NotificationSystem import posli_oznameni
from calculator import Calculator
from nasobilkovac import Nasobilkovac
from stats import stats
from levels import ziskej_level
from streak import aktualizuj_streak
from DLC_Loader import nacti_mathbot_dlc


# ==========================================
# ENDLESS DLC (načítá se externě ze složky DLC)
# ==========================================

def nacti_endless():
    """Vrátí funkci Endless_Mode z DLC/MathBotEndlessDLC.py, nebo None."""
    cesta = os.path.join(slozka, "DLC", "MathBotEndlessDLC.py")

    if not os.path.isfile(cesta):
        return None

    try:
        specifikace = importlib.util.spec_from_file_location(
            "MathBotEndlessDLC", cesta
        )
        modul = importlib.util.module_from_spec(specifikace)
        sys.modules["MathBotEndlessDLC"] = modul

        # Umožní DLC importovat své vlastní soubory ze složky DLC
        dlc_slozka = os.path.dirname(cesta)
        sys.path.insert(0, dlc_slozka)
        try:
            specifikace.loader.exec_module(modul)
        finally:
            if dlc_slozka in sys.path:
                sys.path.remove(dlc_slozka)

        funkce = getattr(modul, "Endless_Mode", None)
        return funkce if callable(funkce) else None

    except Exception as chyba:
        print(f"Endless DLC se nepodařilo načíst: {chyba}")
        return None


endless_funkce = nacti_endless()
endlessmode = endless_funkce is not None

if endlessmode:
    print("MathBot Endless DLC nalezeno!")

statistiky = stats()


# ==========================================
# POMOCNÉ FUNKCE
# ==========================================

def nacti_cislo(text):
    while True:
        try:
            hodnota = int(input(text))
            if hodnota > 0:
                return hodnota
            print("Zadej kladné číslo!")
        except ValueError:
            print("To není číslo!")


# ==========================================
# VÝBĚR HRY
# ==========================================

def vyber_hru():
    while True:
        print("\nČíslo 1 pro příklady")
        print("Číslo 2 pro kalkulačku")
        print("Číslo 3 pro Násobilkovač")
        print("Číslo 4 pro statistiky")
        print("Číslo 5 pro Zlomky")

        moznosti = ["1", "2", "3", "4", "5"]

        if endlessmode:
            print("ModSlot1 pro Endless Mode")
            moznosti.append("ModSlot1")

        if os.path.exists(os.path.join(slozka, "DLC", "MathBotHry.mathbot")):
            print("ModSlot2 pro MathBotHry DLC")
            moznosti.append("ModSlot2")

        hra = input("Zadej číslo pro Hru!: ").strip()

        if hra in moznosti:
            return hra

        print("Hra neexistuje!")


# ==========================================
# 1 - RANDOM PŘÍKLADY
# ==========================================

def hra_priklady():
    pocet = nacti_cislo("Kolik příkladů chceš? ")

    spravne = 0
    spatnecount = 0

    print("\n=== MATHBOT ===")
    print(f"Čeká tě {pocet} příkladů!\n")

    for i in range(pocet):
        operace = random.choice(["+", "-", "*", "/"])

        if operace == "+":
            a = random.randint(1, 100)
            b = random.randint(1, 100)
            odpoved = a + b
        elif operace == "-":
            a = random.randint(1, 100)
            b = random.randint(1, a)
            odpoved = a - b
        elif operace == "*":
            a = random.randint(1, 13)
            b = random.randint(1, 13)
            odpoved = a * b
        else:
            b = random.randint(1, 10)
            odpoved = random.randint(1, 20)
            a = b * odpoved

        print(f"Příklad {i + 1}/{pocet}")

        try:
            vysledek = int(input(f"{a} {operace} {b} = "))

            if vysledek == odpoved:
                print("Správně!\n")
                spravne += 1
                pridej_xp(10)
                print("Získal jsi 10 XP!")
            else:
                print(f"Špatně! Správný výsledek je {odpoved}\n")
                spatnecount += 1

        except ValueError:
            print(f"❌ To není číslo! Správný výsledek je {odpoved}\n")
            spatnecount += 1

    print("================================")
    print("           VÝSLEDEK")
    print("================================")
    print(f"Správně: {spravne}/{pocet}")
    print(f"Špatně: {spatnecount}/{pocet}")

    procenta = (spravne / pocet) * 100
    print(f"Úspěšnost: {procenta:.0f} %")

    if procenta == 100:
        pridej_xp(100)
        print("Získal jsi 100 XP za 100%!")

    if procenta > 50:
        pridej_xp(50)
        print("Získal jsi 50 XP!")
    elif procenta < 50:
        pridej_xp(30)
        print("Získal jsi 30 XP!")

    posli_oznameni("MathBot 🧮", f"Test dokončen! {spravne}/{pocet} správně.")

    input("\nEnter k zavření...")


# ==========================================
# 4 - STATISTIKY
# ==========================================

def hra_statistiky():
    data = ziskej_level()

    print("================================")
    print("       MATHBOT STATISTIKY")
    print("================================")
    print(f"XP: {data['xp']}")
    print(f"Level: {data['level']}")
    print(f"Název levelu: {data['nazev']}")

    if data["xp_do_dalsiho"] > 0:
        print(f"XP do dalšího levelu: {data['xp_do_dalsiho']}")
    else:
        print("Dosáhl jsi maximálního levelu!")

    streak = aktualizuj_streak()
    print(f"Aktuální streak: {streak} dní!")

    input("\nEnter pro zavření...")


# ==========================================
# 5 - ZLOMKY
# ==========================================

def hra_zlomky():
    data = ziskej_level()

    if not data["zlomky_odmknute"]:
        chybi = 2000 - data["xp"]

        print("\n================================")
        print("       ZLOMKY ZAMČENY")
        print("================================")
        print("Zlomky se odemknou na levelu Math Legend!")
        print("Potřebuješ 2000 XP.")
        print(f"Chybí ti ještě {chybi} XP.")
        input("\nEnter pro zavření...")
        return

    print("\n================================")
    print("       MATHBOT ZLOMKY")
    print("================================")
    print("Zlomky odemčeny!")

    pocet = nacti_cislo("Kolik příkladů chceš? ")
    spravne = 0

    for i in range(pocet):
        jmenovatel1 = random.randint(2, 12)
        jmenovatel2 = random.randint(2, 12)
        citatel1 = random.randint(1, jmenovatel1 - 1)
        citatel2 = random.randint(1, jmenovatel2 - 1)

        spravny = Fraction(
            citatel1 * jmenovatel2 + citatel2 * jmenovatel1,
            jmenovatel1 * jmenovatel2,
        )

        print(f"\nPříklad {i + 1}/{pocet}")
        print(f"{citatel1}/{jmenovatel1} + {citatel2}/{jmenovatel2}")
        print("Zadej výsledek jako zlomek. Například: 3/4")

        odpoved = input("Tvoje odpověď: ").strip()

        try:
            uzivatel = Fraction(odpoved)

            if uzivatel == spravny:
                print("Správně! +20 XP")
                pridej_xp(20)
                spravne += 1
            else:
                print(f"Špatně! Správný výsledek je {spravny}")

        except (ValueError, ZeroDivisionError):
            print(f"Neplatný zlomek! Správný výsledek je {spravny}")

    print("\n================================")
    print("       VÝSLEDEK ZLOMKŮ")
    print("================================")
    print(f"Správně: {spravne}/{pocet}")

    procenta = (spravne / pocet) * 100
    print(f"Úspěšnost: {procenta:.0f} %")

    if procenta >= 50:
        print("Dostáváš 250 XP za 50 % a víc!")
        pridej_xp(250)
    else:
        print("Dostáváš 75 XP za míň než 50 %.")
        pridej_xp(75)

    input("\nEnter pro zavření...")


# ==========================================
# ModSlot2 - DLC LOADER
# ==========================================

def hra_dlc_loader():
    print("\n==============================")
    print("      MATHBOT DLC LOADER")
    print("==============================")

    nazev = input(
        "Zadej název DLC nebo cestu k souboru "
        "(Enter = MathBotHry.mathbot): "
    ).strip().strip('"')

    if not nazev:
        nazev = "MathBotHry.mathbot"

    cesta_dlc = os.path.join(slozka, "DLC", nazev)

    if not os.path.exists(cesta_dlc):
        cesta_dlc = nazev

    nacti_mathbot_dlc(cesta_dlc)

    input("\nEnter pro zavření...")


# ==========================================
# HLAVNÍ PROGRAM
# ==========================================

def main():
    hra = vyber_hru()

    if hra == "1":
        hra_priklady()
    elif hra == "2":
        Calculator()
    elif hra == "3":
        Nasobilkovac()
    elif hra == "4":
        hra_statistiky()
    elif hra == "5":
        hra_zlomky()
    elif hra == "ModSlot1":
        endless_funkce()
    elif hra == "ModSlot2":
        hra_dlc_loader()


if __name__ == "__main__":
    main()