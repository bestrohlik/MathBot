import json
import sys
from pathlib import Path

levels = [
    (0, "Začátečník"),
    (100, "Učeň"),
    (300, "Matematik"),
    (600, "Počtář"),
    (1000, "Math Master"),
    (1500, "MathBot Expert"),
    (2000, "Math Legend"),
    (3000, "Math Genius"),
    (5000, "Math God"),
    (10000, "MathBot Immortal"),
    (50000, "MathBot Immortal II"),
    (100000, "MathBot Immortal III"),
    (500000, "MathBot Immortal IV"),
    (1000000, "MathBot Immortal V"),
]


def ziskej_level():
    if getattr(sys, "frozen", False):
        slozka = Path(sys.executable).resolve().parent
    else:
        slozka = Path(__file__).resolve().parent

    soubor = slozka / "statistics.json"

    with open(soubor, "r", encoding="utf-8") as f:
        statistiky = json.load(f)

    xp = int(statistiky["xp"])

    level = 1
    nazev = levels[0][1]

    for i, (hranice, jmeno) in enumerate(levels):
        if xp >= hranice:
            level = i + 1
            nazev = jmeno

    if level < len(levels):
        xp_do_dalsiho = levels[level][0] - xp
    else:
        xp_do_dalsiho = 0

    # Zlomky se odemknou od Math Legend (2000 XP) výše
    zlomky_odmknute = xp >= 2000

    return {
        "xp": xp,
        "level": level,
        "nazev": nazev,
        "xp_do_dalsiho": xp_do_dalsiho,
        "zlomky_odmknute": zlomky_odmknute,
    }