import random
from XPGiver import pridej_xp


def Endless_Mode():
    level = 0
    obtiznost = 0
    q = 10
    w = 1
    g = 0

    print("Endless Mode začíná!")

    while True:
        level += 1
        obtiznost += 1

        # Výběr operace
        z = random.choice(["+", "-", "/", "*"])

        # Zvyšování obtížnosti
        q += 5
        w += g

        print(f"\n===== LEVEL {level} =====")
        print(f"Obtížnost: {obtiznost}")

        g += 1
        g *= 2

        print(f"Rozsah příkladů: {w}-{q}")

        # Generování příkladů
        a = random.randint(w, q)
        b = random.randint(w, q)

        # Zajištění celočíselného dělení
        if z == "/":
            b = random.randint(1, max(1, q))
            a = b * random.randint(1, max(1, q))

        # Správný výsledek
        if z == "+":
            spravna_odpoved = a + b

        elif z == "-":
            spravna_odpoved = a - b

        elif z == "*":
            spravna_odpoved = a * b

        elif z == "/":
            spravna_odpoved = a // b

        print(f"Tvůj příklad: {a} {z} {b}")

        # Zadání odpovědi
        try:
            odpoved = int(input("Tvoje odpověď: "))
        except ValueError:
            print("❌ Zadej platné celé číslo!")
            print(f"Správná odpověď byla {spravna_odpoved}.")
            break

        # Kontrola odpovědi
        if odpoved == spravna_odpoved:
            print("✅ SPRÁVNĚ! +10 XP")
            pridej_xp(10)

        else:
            print(f"❌ Špatně! Správná odpověď byla {spravna_odpoved}.")
            print(f"Dostal ses do levelu {level}!")