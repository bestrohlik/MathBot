def Calculator():

    while True:
        o = input("Operation (+, -, *, /): ")
        a = int(input("first number: "))
        b = int(input("second number: "))

        if o == "+":
            vysledek = a + b
        elif o == "-":
            vysledek = a - b
        elif o == "*":
            vysledek = a * b
        elif o == "/":
            vysledek = a / b
        else:
            print("unknown Operation!")
            continue

        print(f"{a} {o} {b} = {vysledek}")