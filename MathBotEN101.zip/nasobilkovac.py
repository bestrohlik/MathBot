def Nasobilkovac():
    while True:
        q = int(input("to what number?: ")) + 1
        cislo = int(input("what number?: ")) 

        for i in range(1, q):
            print(f"{cislo} × {i} = {cislo * i}")