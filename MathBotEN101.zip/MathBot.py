import random
import os
from XPGiver import pridej_xp
from NotificationSystem import posli_oznameni
from calculator import Calculator
from nasobilkovac import Nasobilkovac
from stats import stats

statistiky = stats()

# Cesta ke složce, kde je tento soubor
slozka = os.path.dirname(os.path.abspath(__file__))

print("Number 1 for Examples")
print("Number 2 for the calculator")
print("Number 3 for multiplier")
print("Number 4 for statistics")

hra = input("Enter a number for the game: ")


# =========================
# RANDOM PŘÍKLADY
# =========================

if hra == "1":

    pocet = int(input("how many examples you want? "))

    spravne = 0
    spatnecount = 0
    spatne = 0

    print("\n=== MATHBOT ===")
    print(f"{pocet} examples awaits you!")

    for i in range(pocet):

        operace = random.choice(["+", "-", "*", "/"])

        if operace == "+":
            a = random.randint(1, 100)
            b = random.randint(1, 100)
            odpoved = a + b

        elif operace == "-":
            a = random.randint(1, 100)
            b = random.randint(1, a)
            odpoved = a - b

        elif operace == "*":
            a = random.randint(1, 13)
            b = random.randint(1, 13)
            odpoved = a * b

        elif operace == "/":
            b = random.randint(1, 10)
            odpoved = random.randint(1, 20)
            a = b * odpoved

        print(f"Example {i + 1}/{pocet}")

        try:
            vysledek = int(input(f"{a} {operace} {b} = "))

            if vysledek == odpoved:

                print("Correct!\n")
                spravne += 1
                pridej_xp(10)
                print("You got 10 XP!")

            else:

                print(f"Wrong! the correct result is {odpoved}\n")
                spatnecount += 1
                spatne += 1

        except ValueError:

            print(
                f"❌ not a number! "
                f"the correct result is {odpoved}\n"
            )

            spatnecount += 1

    print("================================")
    print("           VÝSLEDEK")
    print("================================")

    print(f"Correct: {spravne}/{pocet}")
    print(f"Wrong: {spatnecount}/{pocet}")

    procenta = (spravne / pocet) * 100

    print(f"success rate: {procenta:.0f} %")
    if procenta > 50:
       pridej_xp(50)
       print("You got 50 XP!")

    if procenta < 50:
       pridej_xp(30)
       print("You got 30 XP!")

    posli_oznameni(
        "MathBot 🧮",
        f"test finished! {spravne}/{pocet} correct."
    )

    input("\nEnter to close...")


# =========================
# KALKULAČKA
# =========================

if hra == "2":
    Calculator()


# =========================
# NÁSOBILKOVAČ
# =========================

if hra == "3":
    Nasobilkovac()

if hra == "4":
    print(f"XP: {statistiky['xp']}")
    print(f"STREAK: {statistiky['streak']}")
    input("enter to close...")