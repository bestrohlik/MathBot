import random
from XPGiver import pridej_xp

def Endless_Mode():
    level = 0
    obtiznost = 0
    q = 10

    print("Endless Mode začíná!")

    while True:
        level += 1
        obtiznost += 1
        q += 5

        print(f"\n===== LEVEL {level} =====")
        print(f"Obtížnost: {obtiznost}")
        print(f"Rozsah příkladů: 1-{q}")

        a = random.randint(1, q)
        b = random.randint(1, 9)

        print(f"Tvůj příklad: {a} + {b}")

        odpoved = int(input("Tvoje odpověď: "))

        if odpoved == a + b:
            print("Správně!")
            pridej_xp(15)
            print("Získal jsi 15 XP")
        else:
            print(f"Špatně! Správná odpověď byla {a + b}")

Endless_Mode()