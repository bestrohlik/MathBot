import random
from XPGiver import pridej_xp

def Endless_Mode():
    level = 0
    obtiznost = 0
    q = 10
    w = 1

    print("Endless Mode začíná!")

    while True:
        level += 1
        obtiznost += 1
        q += 5
        w += 1

        print(f"\n===== LEVEL {level} =====")
        print(f"Obtížnost: {obtiznost}")
        print(f"Rozsah příkladů: {w}-{q}")

        a = random.randint(w, q)
        b = random.randint(w, q)

        print(f"Tvůj příklad: {a} + {b}")

        odpoved = int(input("Tvoje odpověď: "))

        if odpoved == a + b:
            print("Správně!")
            pridej_xp(15)
            print("Získal jsi 15 XP")
        else:
            print(f"Špatně! Správná odpověď byla {a + b}")