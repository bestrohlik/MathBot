import random
import os
from XPGiver import pridej_xp
from NotificationSystem import posli_oznameni
from calculator import Calculator
from nasobilkovac import Nasobilkovac
from stats import stats
import random

# Určení kořenové složky (funguje v .py i v .exe přes PyInstaller)
slozka = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))

# Přidání složky do cesty sys.path, aby fungovaly importy
if slozka not in sys.path:
    sys.path.insert(0, slozka)

from XPGiver import pridej_xp
from NotificationSystem import posli_oznameni
from calculator import Calculator
from nasobilkovac import Nasobilkovac
from stats import stats

dlc_cesta = os.path.join(slozka, "DLC", "MathBotEndlessDLC.py")

if os.path.exists(dlc_cesta):
    from DLC.MathBotEndlessDLC import Endless_Mode
    print("MathBot Endless DLC nalezeno!")
    endlessmode = True
else:
    endlessmode = False

statistiky = stats()

# Cesta ke složce, kde je tento soubor
slozka = os.path.dirname(os.path.abspath(__file__))

def vyber_hru():
    while True:
        print("Číslo 1 pro příklady")
        print("Číslo 2 pro kalkulačku")
        print("Číslo 3 pro Násobilkovač")
        print("Číslo 4 pro statistiky")
        moznosti = ["1", "2", "3", "4"]
        if endlessmode:
            print("Číslo 5 pro Endless Mode")
            moznosti.append("5")

        hra = input("Zadej číslo pro Hru!: ")
        
        if hra in moznosti:
            return hra
        else:
             print("hra neexistuje!")
         
hra = vyber_hru()


# =========================
# RANDOM PŘÍKLADY
# =========================

if hra == "1":

    pocet = int(input("Kolik příkladů chceš? "))

    spravne = 0
    spatnecount = 0
    spatne = 0

    print("\n=== MATHBOT ===")
    print(f"Čeká tě {pocet} příkladů!\n")

    for i in range(pocet):

        operace = random.choice(["+", "-", "*", "/"])

        if operace == "+":
            a = random.randint(1, 100)
            b = random.randint(1, 100)
            odpoved = a + b

        elif operace == "-":
            a = random.randint(1, 100)
            b = random.randint(1, a)
            odpoved = a - b

        elif operace == "*":
            a = random.randint(1, 13)
            b = random.randint(1, 13)
            odpoved = a * b

        elif operace == "/":
            b = random.randint(1, 10)
            odpoved = random.randint(1, 20)
            a = b * odpoved

        print(f"Příklad {i + 1}/{pocet}")

        try:
            vysledek = int(input(f"{a} {operace} {b} = "))

            if vysledek == odpoved:

                print("Správně!\n")
                spravne += 1
                pridej_xp(10)
                print("Získal jsi 10 XP!")

            else:

                print(f"Špatně! Správný výsledek je {odpoved}\n")
                spatnecount += 1
                spatne += 1

        except ValueError:

            print(
                f"❌ To není číslo! "
                f"Správný výsledek je {odpoved}\n"
            )

            spatnecount += 1

    print("================================")
    print("           VÝSLEDEK")
    print("================================")

    print(f"Správně: {spravne}/{pocet}")
    print(f"Špatně: {spatnecount}/{pocet}")

    procenta = (spravne / pocet) * 100

    print(f"Úspěšnost: {procenta:.0f} %")
    if procenta > 50:
       pridej_xp(50)
       print("získal si 50 XP!")

    if procenta < 50:
       pridej_xp(30)
       print("Získal jsi 30 XP!")

    posli_oznameni(
        "MathBot 🧮",
        f"Test dokončen! {spravne}/{pocet} správně."
    )

    input("\nEnter k zavření...")


# =========================
# KALKULAČKA
# =========================

if hra == "2":
    Calculator()


# =========================
# NÁSOBILKOVAČ
# =========================

if hra == "3":
    Nasobilkovac()

if hra == "4":
    print(f"XP: {statistiky['xp']}")
    print(f"STREAK: {statistiky['streak']}")
    input("enter to close...")

if endlessmode and hra == "5":
    Endless_Mode()