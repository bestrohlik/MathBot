import json
import os
import sys


def stats():
    if getattr(sys, "frozen", False):
        slozka = os.path.dirname(sys.executable)
    else:
        slozka = os.path.dirname(os.path.abspath(__file__))

    cesta = os.path.join(slozka, "statistics.json")

    with open(cesta, "r", encoding="utf-8") as soubor:
        return json.load(soubor)