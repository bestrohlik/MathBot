import json
import os
import sys


def pridej_xp(hodnota):
    if getattr(sys, "frozen", False):
        slozka = os.path.dirname(sys.executable)
    else:
        slozka = os.path.dirname(os.path.abspath(__file__))

    cesta = os.path.join(slozka, "statistics.json")

    with open(cesta, "r", encoding="utf-8") as soubor:
        data = json.load(soubor)

    data["xp"] += hodnota

    with open(cesta, "w", encoding="utf-8") as soubor:
        json.dump(data, soubor, indent=4, ensure_ascii=False)