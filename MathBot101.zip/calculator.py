def Calculator():

    while True:
        o = input("Operace (+, -, *, /): ")
        a = int(input("První číslo: "))
        b = int(input("Druhé číslo: "))

        if o == "+":
            vysledek = a + b
        elif o == "-":
            vysledek = a - b
        elif o == "*":
            vysledek = a * b
        elif o == "/":
            vysledek = a / b
        else:
            print("Neznámá operace!")
            continue

        print(f"{a} {o} {b} = {vysledek}")