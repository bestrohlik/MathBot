def Nasobilkovac():
    while True:
        cislo = int(input("Jakou násobilku chceš? "))
        q = int(input("do kolikati?: ")) + 1

        for i in range(1, q):
            print(f"{cislo} × {i} = {cislo * i}")