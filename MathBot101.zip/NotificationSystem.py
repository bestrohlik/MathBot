from winotify import Notification

def posli_oznameni(nadpis, zprava):
    toast = Notification(
        app_id="MathBot",
        title=nadpis,
        msg=zprava
    )

    toast.show()


posli_oznameni("MathBot", "Čas na další příklad!")